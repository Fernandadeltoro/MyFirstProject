package com.example.mdtcase4_5;
// Fernanda Del Toro Currency Calculator App Case 4-5 Project 2

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    double dollarsEntered;         //To initialize the amount of dollars entered
    double eurosFromDollars;        //To initialize the euros gotten from the dollars
    double pesosFromDollars;        //To initialize the pesos gotten from the dollars
    double canadianFromDollars;     //To initialize the Canadian dollars gotten from the US dollars

    double euroConversionRate= 0.92;        //Conversion rates for each currency
    double pesosConversionRate = 16.95;
    double canadianConversionRate = 1.35;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.CurrencyConvertorToolbar));
       //This code displays the custom icon in the action bar
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        // To reference the input space from the first screen
        final EditText dollars = (EditText)findViewById(R.id.tvDollars);
        final RadioButton dollarsToPesos =(RadioButton)findViewById(R.id.rbDollarsToPesos);
        final RadioButton dollarsToCanadian = (RadioButton) findViewById(R.id.rbDollarsToCanadian);
        final RadioButton dollarsToEuros = (RadioButton) findViewById(R.id.rbDollarsToEuros);
        final TextView currencyResult = (TextView) findViewById(R.id.tvCurrencyResult); //Reference the result part
        Button converter = (Button)findViewById(R.id.btConverter);

        //Code the event listener
        converter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Here to check for the empty strings

                if(TextUtils.isEmpty(dollars.getText().toString()))
                {
                    currencyResult.setText("");
                    Toast.makeText(MainActivity.this, "Please enter a valid number between 0 and 100,000", Toast.LENGTH_LONG).show();
                    return;
                }
                dollarsEntered=Double.parseDouble(dollars.getText().toString());
                DecimalFormat currency = new DecimalFormat("$###,###.##");
                if(dollarsToPesos.isChecked()){
                    if(dollarsEntered <= 100000) {
                        pesosFromDollars = dollarsEntered * pesosConversionRate;
                        currencyResult.setText(currency.format(pesosFromDollars) + " pesos");
                    } else{
                        Toast.makeText(MainActivity.this, "Dollars must be less than 100,000",
                                Toast.LENGTH_LONG).show();
                    }
                }
                    if(dollarsToCanadian.isChecked()){
                        if(dollarsEntered <= 100000){
                            canadianFromDollars = dollarsEntered * canadianConversionRate;
                            currencyResult.setText(currency.format(canadianFromDollars)+ " canadian dollars");
                        } else {
                            Toast.makeText(MainActivity.this, "Dollars must be less than 100,000",
                                    Toast.LENGTH_LONG).show();
                        }

                    }
                        if(dollarsToEuros.isChecked()){
                            if(dollarsEntered <= 100000){
                                eurosFromDollars = dollarsEntered * euroConversionRate;
                                currencyResult.setText(currency.format(eurosFromDollars)+ " euros");
                            } else {
                                Toast.makeText(MainActivity.this, "Dollars must be less than 100,000",
                                        Toast.LENGTH_LONG).show();
                            }
                        }








            }
        });


    }
}